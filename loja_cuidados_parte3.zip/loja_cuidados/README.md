# Essência Natural – Loja de Cuidados Pessoais

Projeto da disciplina **Programação WEB** – Análise e Desenvolvimento de Sistemas (Claretiano).
**Autor:** [Seu Nome] | **RA:** [Seu RA] | **Semestre:** 4º

**Site publicado:** [cole aqui o link do GitHub Pages / Netlify / Vercel]
**Repositório:** [cole aqui o link do repositório]

> Etapas: **Parte 1** – estrutura HTML · **Parte 2** – estilização com CSS · **Parte 3** – interatividade com JavaScript, documentação e arquitetura (SAD) com Mermaid.js.

---

## 1. Proposta Visual

**Conceito:** a Essência Natural é uma loja fictícia de cuidados pessoais que começou com sabonetes artesanais e hoje vende produtos para pele, corpo e banho. O visual é leve e acolhedor, com verdes de folha, fundos em menta e creme e detalhes em ocre, cores tiradas das ilustrações e do logotipo.

**Público-alvo:** pessoas de 18 a 45 anos que buscam uma rotina de autocuidado simples, com produtos acessíveis e escolhas mais conscientes.

## 2. Guia de Estilo

| Nome | HEX | RGB | Uso |
|---|---|---|---|
| Folha | `#4D8D5B` | 77, 141, 91 | Folha do logotipo, barra de senha forte |
| Folha escura | `#2F6440` | 47, 100, 64 | Botões, menu ativo, contador do carrinho |
| Bosque | `#1F3A27` | 31, 58, 39 | Texto (tema claro) e rodapé |
| Menta | `#E9F4E7` | 233, 244, 231 | Hero e hover do menu |
| Creme | `#FFF4E5` | 255, 244, 229 | Seções alternadas |
| Ocre | `#C78A4B` | 199, 138, 75 | Bordas e foco |
| Ocre claro | `#E3B77F` | 227, 183, 127 | Hover dos botões |

No **tema escuro**, o CSS apenas redefine as variáveis (`--pagina`, `--superficie`, `--texto`, `--link` etc.) dentro de `:root[data-tema="escuro"]`.

**Fontes (Google Fonts):** **Young Serif** (títulos) e **Nunito Sans** (textos).

## 3. Tecnologias

- **HTML5** semântico (`header`, `nav`, `main`, `section`, `article`, `figure`, `details`, `dialog`, `footer`).
- **CSS3 puro** (sem Bootstrap): variáveis, Flexbox, Grid (`auto-fit`/`minmax`), `clamp()` e *media queries*.
- **JavaScript (ES6+) puro**, sem bibliotecas: manipulação do DOM, eventos, RegEx e `localStorage`.
- **Markdown + Mermaid.js** para esta documentação.

## 4. Funcionalidades em JavaScript

Foram implementadas **as quatro opções** sugeridas na atividade, todas em `js/script.js`:

| Opção | Funcionalidade | Onde testar |
|---|---|---|
| **A** | Validação do formulário (`preventDefault`), e-mail com RegEx, erros por campo, mensagem de sucesso/erro sem recarregar e contador de caracteres | `contato.html` |
| **B** | Página de cadastro com máscara de CPF e telefone, validação dos dígitos do CPF, força da senha e confirmação idêntica | `cadastro.html` |
| **C** | Busca em tempo real por nome/categoria (ignora acentos) e carrinho: adicionar, aumentar, diminuir, remover, total em R$ e contador no cabeçalho | `produtos.html` |
| **D** | Botão de tema claro/escuro (🌙/☀️) que salva a preferência no `localStorage` e respeita o tema do sistema na primeira visita | todas as páginas |

Extras: o modal da promoção (Parte 1) foi movido do HTML para o `script.js`, e o carrinho continua salvo ao trocar de página ou recarregar.

**Como testar rapidamente**
1. Em `contato.html`, clique em *Enviar* com tudo em branco e depois digite um e-mail sem domínio (`maria@x`).
2. Em `cadastro.html`, digite o CPF `52998224725` (CPF de teste válido) e veja a máscara. Teste senhas diferentes para ver a barra de força.
3. Em `produtos.html`, adicione itens, mude as quantidades, busque por `rosto` e abra outra página para ver o contador do carrinho.
4. Alterne o tema e recarregue a página.

---

## 5. O que é Markdown e quem o criou?

**Definição:** Markdown é uma linguagem de marcação leve que permite formatar textos em texto puro usando símbolos simples (como `#`, `*`, `**` e `` ` ``), deixando a leitura fácil e permitindo a conversão rápida para HTML.

**História e criadores:** foi criada em **2004** por **John Gruber**, com a colaboração de **Aaron Swartz**, para que as pessoas pudessem escrever textos formatados para a web de forma simples e legível. Hoje é usada em READMEs, documentações, blogs e plataformas como GitHub e GitLab.

## 6. O que é SAD (Software Architecture Document)?

**Definição:** o SAD (Documento de Arquitetura de Software) é um documento da engenharia de software que descreve a arquitetura geral de um sistema. Ele apresenta as visões estruturais, componentes, fluxos de dados, módulos e decisões técnicas, servindo de guia para quem desenvolve e mantém o projeto.

**Decisões técnicas deste projeto**

| Decisão | Motivo |
|---|---|
| Site estático (HTML + CSS + JS), sem back-end | Escopo da disciplina e publicação gratuita em Netlify, Vercel ou GitHub Pages |
| JavaScript puro, sem frameworks | Praticar os fundamentos do DOM, eventos e RegEx |
| Um único `script.js` com módulos por função | Reaproveitar validação e utilitários; cada módulo só roda se a página tiver os elementos |
| Carrinho e tema no `localStorage` | Persistir dados no navegador sem servidor |
| Cores em variáveis CSS | Trocar de tema alterando só o atributo `data-tema` |
| `novalidate` + validação própria | Mensagens de erro personalizadas e acessíveis (`aria-live`, `aria-invalid`) |

**Limitações conhecidas:** não há servidor, então os formulários não enviam dados e a "finalização de compra" é apenas uma simulação.

## 7. O que é Mermaid.js?

**Definição:** Mermaid.js é uma biblioteca baseada em JavaScript que usa uma sintaxe inspirada em Markdown para renderizar diagramas, fluxogramas e gráficos dinamicamente no navegador ou em editores de texto.

## 8. Ferramentas para visualizar e testar diagramas Mermaid

1. **Mermaid Live Editor (oficial):** <https://mermaid.live>. Edição em tempo real, links compartilháveis e exportação em PNG ou SVG.
2. **Mermditor:** <https://www.mermditor.dev/editor>. Editor interativo e leve com pré-visualização instantânea.
3. **Mermaid Chart:** <https://www.mermaidchart.com>. Plataforma para criação colaborativa, com templates e integração com IDEs.
4. **Extensões do VS Code:** *Markdown Preview Mermaid Support* (renderiza blocos ` ```mermaid ` na pré-visualização do Markdown) e *Mermaid Preview* (pré-visualização na barra lateral).
5. **GitHub e GitLab:** renderizam automaticamente blocos ` ```mermaid ` no `README.md`.

---

## 9. Diagramação da arquitetura (SAD) com Mermaid.js

### 9.1 Visão em camadas (arquitetura)

```mermaid
graph LR
    U[Usuário no navegador]
    subgraph View["Apresentação (View)"]
        H1[index.html]
        H2[produtos.html]
        H3[contato.html]
        H4[cadastro.html]
    end
    subgraph Style["Estilização (Style)"]
        C[css/style.css]
    end
    subgraph Ctrl["Lógica (Controller)"]
        J[js/script.js]
    end
    subgraph Dados["Armazenamento no navegador"]
        LS[(localStorage: carrinho e tema)]
    end
    U --> H1
    U --> H2
    U --> H3
    U --> H4
    H1 --- C
    H2 --- C
    H3 --- C
    H4 --- C
    H1 --- J
    H2 --- J
    H3 --- J
    H4 --- J
    J <--> LS
```

### 9.2 Fluxograma de navegação e validação

```mermaid
graph TD
    A[Usuário / Cliente] -->|Acessa o site| B(index.html)
    B -->|Navega pelo menu| C(produtos.html)
    B -->|Navega pelo menu| D(contato.html)
    B -->|Navega pelo menu| D2(cadastro.html)
    C -->|Adicionar ao carrinho| K[script.js - Carrinho e localStorage]
    D -->|Preenche formulário| E[script.js - Validação]
    D2 -->|Preenche formulário| E
    E -->|Dados válidos| F[Exibe mensagem de sucesso]
    E -->|Dados inválidos| G[Exibe erro e destaca campos]
```

### 9.3 Sequência da validação do formulário

```mermaid
sequenceDiagram
    autonumber
    actor Cliente
    participant DOM as Navegador (HTML)
    participant JS as JavaScript (script.js)
    Cliente->>DOM: Preenche formulário e clica em Enviar
    activate DOM
    DOM->>JS: Dispara evento submit (e.preventDefault)
    activate JS
    JS->>JS: Processa validação (campos, RegEx, regras)
    alt Dados corretos
        JS-->>DOM: Exibe mensagem de sucesso e limpa campos
        DOM-->>Cliente: Exibe confirmação na tela
    else Dados incompletos ou erro
        JS-->>DOM: Exibe mensagem de erro no DOM
        DOM-->>Cliente: Exibe alerta de erro e destaca campos
    end
    deactivate JS
    deactivate DOM
```

### 9.4 Fluxo do carrinho de compras

```mermaid
graph TD
    A[Clique em Adicionar ao carrinho] --> B{Produto já está no carrinho?}
    B -->|Sim| C[Aumenta a quantidade]
    B -->|Não| D[Cria o item com quantidade 1]
    C --> E[Salva no localStorage]
    D --> E
    E --> F[Atualiza contador do cabeçalho]
    E --> G[Recalcula lista e total em R$]
```

---

## 10. Especificação de componentes

| Componente / Arquivo | Camada (SAD) | Tecnologia | Responsabilidade principal |
|---|---|---|---|
| `index.html` | Apresentação (View) | HTML5 | Página inicial: boas-vindas, sobre nós, destaques, FAQ e modal da promoção |
| `produtos.html` | Apresentação (View) | HTML5 | Vitrine com busca, botões de carrinho e o carrinho |
| `contato.html` | Apresentação (View) | HTML5 | Formulário de dúvidas, informações institucionais e mapa |
| `cadastro.html` | Apresentação (View) | HTML5 | Formulário de cadastro de clientes |
| `css/style.css` | Estilização (Style) | CSS3 | Identidade visual, cores, tipografia, grid/flexbox, responsividade e tema escuro |
| `js/script.js` | Lógica e Interatividade (Controller) | JavaScript (ES6+) | Eventos do DOM, validações (RegEx), máscaras, tema, busca e carrinho |
| `README.md` | Documentação técnica | Markdown e Mermaid | Documentação, conceitos de SAD, diagramas e instruções |

## 11. Matriz de responsabilidade por funcionalidade

| Requisito / Funcionalidade | HTML (`*.html`) | CSS (`style.css`) | JS (`script.js`) | Doc (`README.md`) |
|---|---|---|---|---|
| Estrutura semântica e navegação | **Principal** (estrutura) | Suporte (menu/layout) | — | — |
| Design responsivo e estilização | Suporte (classes/IDs) | **Principal** (regras CSS) | Suporte (troca de classes) | — |
| Validação de formulários (campos e RegEx) | Suporte (inputs/forms) | Suporte (estilos de erro) | **Principal** (validação) | — |
| Máscaras e força da senha (cadastro) | Suporte (inputs) | Suporte (barra de força) | **Principal** (máscaras e regras) | — |
| Alternância de tema (dark/light) | Suporte (botão toggle) | Suporte (variáveis CSS) | **Principal** (lógica e storage) | — |
| Busca de produtos | Suporte (campo e `data-*`) | Suporte (`[hidden]`) | **Principal** (filtro) | — |
| Carrinho de compras | Suporte (badges/botões) | Suporte (feedback visual) | **Principal** (contador e total) | — |
| Documentação da arquitetura (SAD e Mermaid) | — | — | — | **Principal** (diagramas) |

## 12. Estrutura de pastas

```
loja_cuidados/
├── css/
│   └── style.css        # estilos das quatro páginas e tema escuro
├── js/
│   └── script.js        # toda a interatividade (7 módulos)
├── imagens/
│   ├── favicon.svg      # ícone da aba e logotipo
│   ├── sabonete.svg
│   ├── hidratante.svg
│   ├── serum.svg
│   └── oleo.svg
├── index.html           # página inicial
├── produtos.html        # catálogo, busca e carrinho
├── contato.html         # formulário validado, informações e mapa
├── cadastro.html        # cadastro com máscaras e senha
└── README.md            # esta documentação
```

## 13. Como executar e publicar

1. Abra a pasta no **VS Code** e o `index.html` no navegador (ou use a extensão *Live Server*).
2. Publicação: arraste a pasta para o **Netlify Drop**, ou envie ao **GitHub** e ative o **GitHub Pages**. Teste o link em aba anônima.
3. O arquivo principal é `index.html` e todos os caminhos são relativos.
