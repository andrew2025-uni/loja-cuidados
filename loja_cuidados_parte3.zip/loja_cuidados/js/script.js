/* =====================================================
   Essência Natural – js/script.js (Parte 3)
   Disciplina: Programação WEB | JavaScript puro (ES6+)

   Módulos:
   1. Utilitários            5. Cadastro (máscaras e senha)
   2. Tema claro/escuro      6. Vitrine: busca em tempo real
   3. Modal da promoção      7. Carrinho de compras
   4. Contato (validação)
   Cada módulo só roda se os elementos dele existirem na
   página, então o mesmo arquivo serve para todas as páginas.
   ===================================================== */
'use strict';

/* ---------- 1. Funções utilitárias ---------- */
const $ = (seletor, contexto = document) => contexto.querySelector(seletor);
const $$ = (seletor, contexto = document) => [...contexto.querySelectorAll(seletor)];
const moeda = (valor) => valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const soDigitos = (texto) => texto.replace(/\D/g, '');
// Remove acentos e deixa minúsculo: "Hidratação" -> "hidratacao" (busca sem se preocupar com acentos)
const normalizar = (texto) => texto.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

// localStorage pode falhar (modo privado, bloqueio), por isso fica dentro de try/catch
function lerStorage(chave, padrao) {
  try {
    const bruto = localStorage.getItem(chave);
    return bruto ? JSON.parse(bruto) : padrao;
  } catch (erro) {
    return padrao;
  }
}
function salvarStorage(chave, valor) {
  try {
    localStorage.setItem(chave, JSON.stringify(valor));
  } catch (erro) {
    /* sem armazenamento: o site continua funcionando, só não lembra a escolha */
  }
}

// Mostra mensagem de sucesso/erro em um elemento .status (sem recarregar a página)
function mostrarStatus(elemento, tipo, texto) {
  elemento.textContent = texto;
  elemento.className = `status ${tipo}`; // tipo = 'erro' ou 'sucesso' (cores no CSS)
}

// Mostra (ou limpa) o erro de um campo. Devolve true quando o campo está válido.
function marcarCampo(campo, mensagem) {
  const aviso = $(`#erro-${campo.id}`);
  if (aviso) aviso.textContent = mensagem;
  campo.classList.toggle('invalido', Boolean(mensagem));
  campo.setAttribute('aria-invalid', mensagem ? 'true' : 'false');
  return !mensagem;
}

/* Liga a validação a um formulário.
   regras = lista de { campo, verificar(valor) -> mensagem de erro ou '' } */
function configurarValidacao(form, regras, status, aoSucesso) {
  const validar = (regra) => marcarCampo(regra.campo, regra.verificar(regra.campo.value));

  regras.forEach((regra) => {
    // Valida quando o usuário sai do campo...
    regra.campo.addEventListener('blur', () => validar(regra));
    // ...e, se já estava com erro, revalida enquanto digita para o aviso sumir na hora
    regra.campo.addEventListener('input', () => {
      if (regra.campo.classList.contains('invalido')) validar(regra);
    });
  });

  form.addEventListener('submit', (evento) => {
    evento.preventDefault(); // impede o envio/recarregamento da página
    // map (e não some/every direto) para validar TODOS os campos e mostrar todos os erros de uma vez
    const todosValidos = regras.map(validar).every(Boolean);
    if (!todosValidos) {
      mostrarStatus(status, 'erro', 'Erro: corrija os campos destacados e tente novamente.');
      $('.invalido', form).focus();
      return;
    }
    aoSucesso();
  });
}

/* ---------- 2. Tema claro/escuro (Opção D) ---------- */
function iniciarTema() {
  const botao = $('#btn-tema');
  if (!botao) return;

  const aplicar = (tema) => {
    document.documentElement.dataset.tema = tema; // o CSS troca as variáveis conforme [data-tema]
    const escuro = tema === 'escuro';
    botao.innerHTML = escuro ? '&#9728;&#65039;' : '&#127769;'; // ☀️ ou 🌙
    botao.setAttribute('aria-pressed', String(escuro));
    botao.setAttribute('aria-label', escuro ? 'Ativar tema claro' : 'Ativar tema escuro');
  };

  aplicar(document.documentElement.dataset.tema || 'claro');

  botao.addEventListener('click', () => {
    const novo = document.documentElement.dataset.tema === 'escuro' ? 'claro' : 'escuro';
    aplicar(novo);
    try {
      localStorage.setItem('tema', novo); // lembra a preferência nas próximas visitas
    } catch (erro) {
      /* ignora */
    }
  });
}

/* ---------- 3. Modal da promoção (página inicial) ---------- */
function iniciarModal() {
  const modal = $('#modal-promocao');
  const abrir = $('#abrir-promocao');
  if (!modal || !abrir) return;

  abrir.addEventListener('click', () => modal.showModal());
  $('#fechar-promocao').addEventListener('click', () => modal.close());
  // Clicar fora da caixa (no fundo escurecido) também fecha
  modal.addEventListener('click', (evento) => {
    if (evento.target === modal) modal.close();
  });
}

/* ---------- 4. Formulário de contato (Opção A) ---------- */
const REGEX_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// Mensagem de erro para e-mail ('' = válido). Usada no contato e no cadastro.
function erroEmail(valor) {
  const email = valor.trim();
  if (!email) return 'Informe seu e-mail.';
  return REGEX_EMAIL.test(email) ? '' : 'Digite um e-mail válido, como nome@exemplo.com.';
}
const erroNome = (valor) => (valor.trim().length < 3 ? 'Informe seu nome (mínimo de 3 letras).' : '');

function iniciarContato() {
  const form = $('#form-contato');
  if (!form) return;

  const nome = $('#nome');
  const email = $('#email');
  const mensagem = $('#mensagem');
  const contador = $('#contador');
  const status = $('#status-msg');
  const limite = Number(mensagem.getAttribute('maxlength'));

  // Contador de caracteres em tempo real
  mensagem.addEventListener('input', () => {
    contador.textContent = `${mensagem.value.length} / ${limite}`;
    contador.classList.toggle('limite', mensagem.value.length >= limite * 0.9); // avisa perto do limite
  });

  configurarValidacao(
    form,
    [
      { campo: nome, verificar: erroNome },
      { campo: email, verificar: erroEmail },
      { campo: mensagem, verificar: (v) => (v.trim().length < 10 ? 'Escreva pelo menos 10 caracteres.' : '') },
    ],
    status,
    () => {
      const primeiroNome = nome.value.trim().split(' ')[0];
      mostrarStatus(status, 'sucesso', `Sucesso: obrigado, ${primeiroNome}! Recebemos sua mensagem.`);
      form.reset();
      contador.textContent = `0 / ${limite}`;
    }
  );
}

/* ---------- 5. Cadastro: máscaras e senha (Opção B) ---------- */
// Máscara de CPF: 12345678901 -> 123.456.789-01
function mascaraCPF(texto) {
  return soDigitos(texto)
    .slice(0, 11)
    .replace(/^(\d{3})(\d)/, '$1.$2')
    .replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3')
    .replace(/\.(\d{3})(\d)/, '.$1-$2');
}

// Máscara de telefone: aceita celular (11 dígitos) e fixo (10 dígitos)
function mascaraTelefone(texto) {
  const d = soDigitos(texto).slice(0, 11);
  if (d.length === 0) return '';
  if (d.length <= 2) return `(${d}`;
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}

// Validação dos dígitos verificadores do CPF (algoritmo oficial)
function cpfValido(texto) {
  const d = soDigitos(texto);
  if (d.length !== 11 || /^(\d)\1{10}$/.test(d)) return false; // rejeita 111.111.111-11 etc.
  const digito = (qtd) => {
    let soma = 0;
    for (let i = 0; i < qtd; i++) soma += Number(d[i]) * (qtd + 1 - i);
    const resto = (soma * 10) % 11;
    return resto === 10 ? 0 : resto;
  };
  return digito(9) === Number(d[9]) && digito(10) === Number(d[10]);
}

// Pontua a senha: tamanho, maiúsculas+minúsculas, número e símbolo
function avaliarSenha(senha) {
  if (!senha) return { nivel: 0, texto: 'Digite uma senha' };
  let pontos = 0;
  if (senha.length >= 8) pontos++;
  if (senha.length >= 12) pontos++;
  if (/[a-z]/.test(senha) && /[A-Z]/.test(senha)) pontos++;
  if (/\d/.test(senha)) pontos++;
  if (/[^A-Za-z0-9]/.test(senha)) pontos++;
  if (pontos <= 2) return { nivel: 1, texto: 'Senha fraca' };
  if (pontos <= 4) return { nivel: 2, texto: 'Senha média' };
  return { nivel: 3, texto: 'Senha forte' };
}

function iniciarCadastro() {
  const form = $('#form-cadastro');
  if (!form) return;

  const nome = $('#nome');
  const cpf = $('#cpf');
  const telefone = $('#telefone');
  const email = $('#email');
  const senha = $('#senha');
  const confirmar = $('#confirmar');
  const status = $('#status-msg');
  const barra = $('#forca-barra');
  const textoForca = $('#forca-texto');

  // Máscaras aplicadas enquanto o usuário digita
  cpf.addEventListener('input', () => (cpf.value = mascaraCPF(cpf.value)));
  telefone.addEventListener('input', () => (telefone.value = mascaraTelefone(telefone.value)));

  // Indicador de força da senha
  senha.addEventListener('input', () => {
    const { nivel, texto } = avaliarSenha(senha.value);
    barra.dataset.nivel = nivel;
    textoForca.textContent = texto;
    if (confirmar.value) marcarCampo(confirmar, erroConfirmar(confirmar.value)); // mantém a confirmação atualizada
  });

  const erroConfirmar = (valor) => {
    if (!valor) return 'Confirme sua senha.';
    return valor === senha.value ? '' : 'As senhas não são idênticas.';
  };

  configurarValidacao(
    form,
    [
      { campo: nome, verificar: erroNome },
      { campo: cpf, verificar: (v) => (cpfValido(v) ? '' : 'CPF inválido. Confira os números.') },
      {
        campo: telefone,
        verificar: (v) => {
          const d = soDigitos(v);
          const ok = d.length === 10 || (d.length === 11 && d[2] === '9');
          return ok ? '' : 'Telefone inválido. Ex.: (19) 99999-9999.';
        },
      },
      { campo: email, verificar: erroEmail },
      {
        campo: senha,
        verificar: (v) => {
          if (v.length < 8) return 'A senha precisa ter pelo menos 8 caracteres.';
          return avaliarSenha(v).nivel < 2 ? 'Senha fraca: misture maiúsculas, minúsculas, números e símbolos.' : '';
        },
      },
      { campo: confirmar, verificar: erroConfirmar },
    ],
    status,
    () => {
      mostrarStatus(status, 'sucesso', `Sucesso: cadastro de ${nome.value.trim().split(' ')[0]} concluído!`);
      form.reset(); // a senha nunca é guardada: não há servidor nesta etapa
      barra.dataset.nivel = 0;
      textoForca.textContent = 'Digite uma senha';
    }
  );
}

/* ---------- 6. Vitrine: busca em tempo real (Opção C) ---------- */
function iniciarBusca() {
  const campo = $('#busca');
  if (!campo) return;

  const cards = $$('.card[data-id]');
  const resultado = $('#resultado-busca');

  campo.addEventListener('input', () => {
    const termo = normalizar(campo.value.trim());
    let visiveis = 0;

    cards.forEach((card) => {
      // Procura no nome, na categoria (data-categoria) e na descrição do produto
      const descricao = $('p', card) ? $('p', card).textContent : '';
      const texto = normalizar(`${card.dataset.nome} ${card.dataset.categoria} ${descricao}`);
      const mostrar = texto.includes(termo);
      card.hidden = !mostrar;
      if (mostrar) visiveis++;
    });

    if (!termo) resultado.textContent = '';
    else resultado.textContent = visiveis ? `${visiveis} produto(s) encontrado(s).` : 'Nenhum produto encontrado.';
  });
}

/* ---------- 7. Carrinho de compras (Opção C) ---------- */
// Estrutura salva no localStorage: { "sabonete-de-lavanda": { nome, preco, qtd }, ... }
let carrinho = lerStorage('carrinho', {});

// Cria um elemento com texto e classe (evita montar HTML em string)
function criar(tag, texto = '', classe = '') {
  const el = document.createElement(tag);
  if (texto) el.textContent = texto;
  if (classe) el.className = classe;
  return el;
}

function botaoControle(texto, acao, id, rotulo) {
  const b = criar('button', texto);
  b.type = 'button';
  b.dataset.acao = acao;
  b.dataset.id = id;
  b.setAttribute('aria-label', rotulo);
  return b;
}

function atualizarCarrinho() {
  const itens = Object.entries(carrinho);
  const quantidade = itens.reduce((soma, [, item]) => soma + item.qtd, 0);
  const total = itens.reduce((soma, [, item]) => soma + item.qtd * item.preco, 0);

  // Contador (badge) do cabeçalho: existe em todas as páginas
  $$('.carrinho-qtd').forEach((el) => (el.textContent = quantidade));

  const lista = $('#lista-carrinho');
  if (!lista) return; // fora da página de produtos só o contador é atualizado

  lista.replaceChildren(); // limpa a lista antes de desenhar de novo
  itens.forEach(([id, item]) => {
    const li = criar('li');
    const info = criar('div', '', 'item-info');
    info.append(criar('strong', item.nome), criar('span', `${item.qtd} × ${moeda(item.preco)} = ${moeda(item.qtd * item.preco)}`));

    const controles = criar('div', '', 'item-ctrl');
    controles.append(
      botaoControle('−', 'menos', id, `Diminuir quantidade de ${item.nome}`),
      botaoControle('+', 'mais', id, `Aumentar quantidade de ${item.nome}`),
      botaoControle('Remover', 'remover', id, `Remover ${item.nome} do carrinho`)
    );
    li.append(info, controles);
    lista.append(li);
  });

  $('#carrinho-vazio').hidden = quantidade > 0;
  $('#carrinho-total').textContent = moeda(total);
  $('#btn-finalizar').disabled = quantidade === 0;
  $('#btn-limpar').disabled = quantidade === 0;
}

function salvarCarrinho() {
  salvarStorage('carrinho', carrinho);
  atualizarCarrinho();
}

function iniciarCarrinho() {
  atualizarCarrinho(); // mostra o que já estava salvo ao abrir qualquer página

  // Botões "Adicionar ao carrinho" (delegação de eventos: um único listener para todos)
  document.addEventListener('click', (evento) => {
    const botao = evento.target.closest('.btn-add');
    if (!botao) return;
    const card = botao.closest('.card');
    const { id, nome, preco } = card.dataset;

    if (!carrinho[id]) carrinho[id] = { nome, preco: Number(preco), qtd: 0 };
    carrinho[id].qtd++;
    salvarCarrinho();

    // Feedback visual rápido no botão
    botao.textContent = 'Adicionado ✓';
    setTimeout(() => (botao.textContent = 'Adicionar ao carrinho'), 1200);
  });

  const lista = $('#lista-carrinho');
  if (!lista) return;
  const status = $('#carrinho-status');

  // Botões −, + e Remover de cada item
  lista.addEventListener('click', (evento) => {
    const botao = evento.target.closest('button[data-acao]');
    if (!botao) return;
    const { acao, id } = botao.dataset;
    if (acao === 'mais') carrinho[id].qtd++;
    if (acao === 'menos') carrinho[id].qtd--;
    if (acao === 'remover' || carrinho[id].qtd <= 0) delete carrinho[id];
    salvarCarrinho();
  });

  $('#btn-limpar').addEventListener('click', () => {
    carrinho = {};
    salvarCarrinho();
    mostrarStatus(status, 'sucesso', 'Carrinho esvaziado.');
  });

  $('#btn-finalizar').addEventListener('click', () => {
    const itens = Object.values(carrinho);
    const qtd = itens.reduce((s, i) => s + i.qtd, 0);
    const total = itens.reduce((s, i) => s + i.qtd * i.preco, 0);
    carrinho = {};
    salvarCarrinho();
    mostrarStatus(status, 'sucesso', `Compra simulada: ${qtd} item(ns), total de ${moeda(total)}. Obrigado!`);
  });
}

/* ---------- Inicialização ---------- */
document.addEventListener('DOMContentLoaded', () => {
  iniciarTema();
  iniciarModal();
  iniciarContato();
  iniciarCadastro();
  iniciarBusca();
  iniciarCarrinho();
});
